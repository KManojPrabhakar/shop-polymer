import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-filled-button',
  templateUrl: './filled-button.component.html',
  styleUrls: ['./filled-button.component.css']
})
export class FilledButtonComponent implements OnInit {
  @Input() buttonName: string;

  constructor() { }

  ngOnInit(): void {
  }

}
