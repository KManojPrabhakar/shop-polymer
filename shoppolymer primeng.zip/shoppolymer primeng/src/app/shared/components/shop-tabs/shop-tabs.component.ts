import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-shop-tabs',
  templateUrl: './shop-tabs.component.html',
  styleUrls: ['./shop-tabs.component.css']
})
export class ShopTabsComponent implements OnInit {
  tabNames = [ 
    {
      name: `Men's Outware`,
      id: 1,
      "category": "mens_outerwear",
    },
    {
      name: 'Ladies Outware',
      id: 2,
      "category": "ladies_outerwear",

    },
    {
      name: `Men's T-Shirts`,
      id: 3,
      "category": "mens_tshirts",

    },
    {
      name: `Ladies T-Shirts`,
      id: 4,
      "category": "ladies_tshirts",

    },
  ];
  selectedId: any;
  currentCategoryName: string;
  constructor(private router: Router, private activatedRoute: ActivatedRoute) { }

  ngOnInit(): void {
    // this.activatedRoute.params.subscribe(params => {
    //   console.log('ShopTabsComponent params', params)
    //   this.selectedId = params.id;
    //   this.currentCategoryName = params.categoryName;

    // })
  }

  handleTabName(data) {
    console.log('handleTabName', data);
    const url = `list/${data.category}`;
    this.selectedId = data.id;
    this.currentCategoryName = data.category;

    this.router.navigate([url]);
  }

}
