import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import {  FormsModule } from '@angular/forms';

import { ButtonComponent } from './components/button/button.component';
import { FilledButtonComponent } from './components/filled-button/filled-button.component';
import { ShopTabsComponent } from './components/shop-tabs/shop-tabs.component';
import { CustomSelectComponent } from './components/custom-select/custom-select.component';
import { RouterModule } from '@angular/router';
import { PrimeModule } from './primeng-module';


const Components = [ButtonComponent, FilledButtonComponent, ShopTabsComponent, CustomSelectComponent];
@NgModule({
  declarations: [...Components],
  imports: [
    CommonModule,
    FormsModule,
    PrimeModule,
    RouterModule
  ],
  exports: [...Components, PrimeModule]
})
export class SharedModule { }
