import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-primeng',
  templateUrl: './primeng.component.html',
  styleUrls: ['./primeng.component.css']
})
export class PrimengComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
