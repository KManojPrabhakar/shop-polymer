import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { Subject } from 'rxjs';

import { ProductsData } from 'src/app/shared/constants/products.constant';

 

@Injectable({
  providedIn: 'root'
})
export class HelperService {
  quantityOptionsData = [ 
    {
      name: 1,
      id: 1
    },
    {
      name: 2,
      id: 2
    },
    {
      name: 3,
      id: 3
    }
  ];
  sizeOptionsData = [ 
    {
      name: 'M',
      id: 1
    },
    {
      name: 'S',
      id: 2
    },
    {
      name: 'L',
      id: 3
    }
  ];
  productsData = ProductsData;
  private cartSubject: Subject<any> = new Subject();

  constructor(private router: Router) { }
 
 getQuantityOptionsData() {
   return this.quantityOptionsData;
 }

 getSizeOptionsData() {
   return this.sizeOptionsData;
 }
 getProductsData() {
   return this.productsData;
 }

 setCartsData(cartsData) {
  sessionStorage.setItem('cartData',JSON.stringify(cartsData));

  }
 getCartsData() {
  return sessionStorage.getItem('cartData');
  }

  setListenerForCartsLength() {
    return this.cartSubject.asObservable();
  }

  storeCartLength(data) {
    this.cartSubject.next(data);
  }
}
