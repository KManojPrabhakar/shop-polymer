import { Injectable } from '@angular/core';
import {  Observable } from 'rxjs';
// import { map, takeUntil } from 'rxjs/operators';

import { ApiService } from './api.service';

@Injectable({
  providedIn: 'root'
})
export class SharedService {
  constructor(private apiService: ApiService) { }
  
  

  getProductsData(): Observable <any> {
    const url = `src/app/shared/constants/products.json`;
    return this.apiService.get(url);
  }

}
