import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { HelperService } from 'src/app/core/services/helper.service';

@Component({
  selector: 'app-cart-item',
  templateUrl: './cart-item.component.html',
  styleUrls: ['./cart-item.component.css']
})
export class CartItemComponent implements OnInit {

  @Input() cartData: any;
  @Output() emitRemoveCartItem = new EventEmitter();
  @Output() emitCartItemQuantity = new EventEmitter();

  quantityOptionsData: any;
  constructor(private  helperService: HelperService) { }

  ngOnInit(): void {
    this.quantityOptionsData = this.helperService.getQuantityOptionsData();
    console.log('cartData', this.cartData);
  }

  handleQuantityOptionData(quantityData, cartData) {
    const data = {
      quantityData,
      cartData
    }
    console.log('cart handleQuantityOptionData', data);
    this.emitCartItemQuantity.emit(data);
  }
  handleRemoveCartItem(cartData) {
    this.emitRemoveCartItem.emit(cartData);
  }

}
