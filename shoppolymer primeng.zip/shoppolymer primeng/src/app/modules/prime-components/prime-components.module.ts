import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { SharedModule } from 'src/app/shared/shared.module';

import { RatingComponent } from './rating/rating.component';
import { SliderComponent } from './slider/slider.component';
import { TabMenuComponent } from './tab-menu/tab-menu.component';
import { AccordianComponent } from './accordian/accordian.component';
import { SelectComponent } from './select/select.component';
import { LightboxComponent } from './lightbox/lightbox.component';
import { ToastComponent } from './toast/toast.component';
import { CalenderComponent } from './calender/calender.component';
import { TableComponent } from './table/table.component';
import { ChartsComponent } from './charts/charts.component';
import { CarousalComponent } from './carousal/carousal.component';
import { DataviewComponent } from './dataview/dataview.component';

import { PrimeComponentsRoutingModule } from './prime-components-routing.module';

@NgModule({
  declarations: [ RatingComponent, SliderComponent, TabMenuComponent,
     AccordianComponent, SelectComponent, LightboxComponent, ToastComponent,
     CalenderComponent, TableComponent, ChartsComponent, CarousalComponent, DataviewComponent],
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    SharedModule,
    PrimeComponentsRoutingModule,
  ]
})
export class PrimeComponentsModule { }
