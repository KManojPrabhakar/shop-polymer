import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-lightbox',
  templateUrl: './lightbox.component.html',
  styleUrls: ['./lightbox.component.css']
})
export class LightboxComponent implements OnInit {
  images: any[];

  constructor() {
      this.images = [];
      this.images.push({source: '../../../../assets/lo1.jpg', thumbnail: '../../../../assets/lo1.jpg', title: 'item 1'});
      this.images.push({source: '../../../../assets/lo2.jpg', thumbnail: '../../../../assets/lo2.jpg', title: 'item 2'});
  }
  ngOnInit() {
  }

}
