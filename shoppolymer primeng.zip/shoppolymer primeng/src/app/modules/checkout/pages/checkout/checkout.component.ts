import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { HelperService } from 'src/app/core/services/helper.service';

@Component({
  selector: 'app-checkout',
  templateUrl: './checkout.component.html',
  styleUrls: ['./checkout.component.css']
})
export class CheckoutComponent implements OnInit {
  shippingAddressForm: FormGroup;
  billingAddressForm: FormGroup;
  cartsData: any;
  cartsTotalValue: any;
  showBillingAddressForm: boolean;

  constructor(private helperService: HelperService) { }

  ngOnInit(): void {
    this.shippingAddressForm = new FormGroup({
      email: new FormControl('', [Validators.required]),
      number: new FormControl('', [Validators.required]),
      address: new FormControl('', [Validators.required]),
      city: new FormControl('', [Validators.required]),
      state: new FormControl('', [Validators.required]),
      zipCode: new FormControl('', [Validators.required]),
      country: new FormControl('', [Validators.required]),
      cardHolderName: new FormControl('', [Validators.required]),
      cardNumber: new FormControl('', [Validators.required]),

    });

    this.billingAddressForm = new FormGroup({
      address: new FormControl('', [Validators.required]),
      city: new FormControl('', [Validators.required]),
      state: new FormControl('', [Validators.required]),
      zipCode: new FormControl('', [Validators.required]),
      country: new FormControl('', [Validators.required]),

    });
    this.cartsData = this.helperService.getCartsData();
    if(this.cartsData) {
      this.cartsData = JSON.parse(this.cartsData);
    }
    this.cartsTotalValue = this.getCartsTotalValue();

  }

  toggleBillingAddress() {
    this.showBillingAddressForm = !this.showBillingAddressForm;
  }
  getCartsTotalValue() {
    let total;
    total = 0;
    this.cartsData.map((item) => {
      total+= item.price * item.quantity;
    })
    total = Number(total).toFixed(2);
    return total;
 }

 handlePlaceOrder() {
   console.log('handlePlaceOrder');
 }
}
