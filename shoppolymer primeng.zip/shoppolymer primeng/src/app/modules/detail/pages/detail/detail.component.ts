import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { HelperService } from 'src/app/core/services/helper.service';

@Component({
  selector: 'app-detail',
  templateUrl: './detail.component.html',
  styleUrls: ['./detail.component.css']
})
export class DetailComponent implements OnInit {

  sizeOptionsData: any;
  quantityOptionsData: any;
  selectedProductData: any;
  productName: string;
  categoryName: string;
  cartsData :any;
  selectedSizeIndex = 0;
  selectedQuantityIndex = 0;
  selectedSizeData: any;
  selectedQuantityData: any;
  constructor(private activatedRoute: ActivatedRoute, private helperService: HelperService, private router: Router) { }

  ngOnInit(): void {
    this.cartsData = [];
    this.cartsData = this.helperService.getCartsData();
    this.sizeOptionsData = this.helperService.getSizeOptionsData();
    this.quantityOptionsData = this.helperService.getQuantityOptionsData();
    if(this.cartsData && this.cartsData.length) {
      this.cartsData = JSON.parse(this.cartsData);
    }  else {
      this.cartsData = [];
    }
    this.productName = this.activatedRoute.snapshot.paramMap.get('productName');
    this.categoryName = this.activatedRoute.snapshot.paramMap.get('categoryName');

    console.log('DetailComponent productName', this.productName, 'categoryName', this.categoryName);
    this.getCurrentProductData();
    this.handleSizeOptionData(this.sizeOptionsData[this.selectedSizeIndex]);
    this.handleQuantityOptionData(this.quantityOptionsData[this.selectedQuantityIndex]);

  }

  getCurrentProductData() {
    const productsData = this.helperService.getProductsData();
    const categoryIndex = productsData.findIndex((item) => item.category === this.categoryName);
    if(categoryIndex !== -1) {
      const productIndex = productsData[categoryIndex].products.findIndex((item) => item.name === this.productName);
      if(productIndex !== -1) {
        this.selectedProductData = productsData[categoryIndex].products[productIndex];
        console.log('this.selectedProductData', this.selectedProductData);
      }
    }
  }

  handleAddToCart(selectedProductData) {
    console.log('handleAddToCart', selectedProductData);
    selectedProductData.size = this.selectedSizeData.name;
    selectedProductData.quantity = this.selectedQuantityData.name;
    this.cartsData.push(selectedProductData);
  
    this.helperService.setCartsData(this.cartsData)
    this.helperService.storeCartLength(this.cartsData.length);

    this.navigateToCartPage();
  }

  navigateToCartPage() {
    const url = `cart`;
    this.router.navigate([url]);

  }

  handleSizeOptionData(data) {
    this.selectedSizeData = data;
    console.log('handleSizeOptionData', data);
  }

  handleQuantityOptionData(data) {
    this.selectedQuantityData = data;
    console.log('handleQuantityOptionData', data);
  }
}
