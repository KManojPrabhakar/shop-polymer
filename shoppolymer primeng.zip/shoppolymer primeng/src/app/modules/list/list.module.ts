import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ListComponent } from './pages/list/list.component';

import { ListRoutingModule} from './list-routing.module';
import { ShopListItemComponent } from './components/shop-list-item/shop-list-item.component';

@NgModule({
  declarations: [ListComponent, ShopListItemComponent],
  imports: [
    CommonModule,
    ListRoutingModule
  ]
})
export class ListModule { }
