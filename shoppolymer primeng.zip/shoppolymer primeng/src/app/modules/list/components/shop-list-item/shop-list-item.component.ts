import { Component, OnInit, Input } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-shop-list-item',
  templateUrl: './shop-list-item.component.html',
  styleUrls: ['./shop-list-item.component.css']
})
export class ShopListItemComponent implements OnInit {

  @Input() productData: any;
  constructor(private router: Router) { }

  ngOnInit(): void {
    console.log(' ShopListItemComponent productData', this.productData);
  }

  navigateToDetailPage(productData) {
    console.log('productData', productData);
    const url = `detail/${productData.category}/${productData.name}`;
    this.router.navigate([url]);
  }
}
