import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { HelperService } from '../services/helper.service';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {

 cartLength: number;
 cartsData: any;
  constructor(private router: Router, private helperService: HelperService) { }

  ngOnInit(): void {
    this.setListenerForCartsLength();
    this.cartsData = this.helperService.getCartsData();
    if(this.cartsData) {
      this.cartsData = JSON.parse(this.cartsData);
    }    
    this.helperService.storeCartLength(this.cartsData.length);

  }

  setListenerForCartsLength() {
    this.helperService.setListenerForCartsLength().subscribe(data => {
      console.log('setListenerForCartsLength data: ', data);
      this.cartLength = data;
    });
  }
  navigateToCartPage() {
    const url = `cart`;
    this.router.navigate([url]);

  }
}
