import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';


const routes: Routes = [
  {
    path: '',
    loadChildren: () => import('src/app/modules/home/home.module').then(m => m.HomeModule)
  },
  {
    path: 'list/:categoryName',
    loadChildren: () => import('src/app/modules/list/list.module').then(m => m.ListModule)
  },
  {
    path: 'detail/:categoryName/:productName',
    loadChildren: () => import('src/app/modules/detail/detail.module').then(m => m.DetailModule)
  },
  {
    path: 'cart',
    loadChildren: () => import('src/app/modules/cart/cart.module').then(m => m.CartModule)
  },
  {
    path: 'checkout',
    loadChildren: () => import('src/app/modules/checkout/checkout.module').then(m => m.CheckoutModule)
  }, 
  {
    path: 'primeng',
    loadChildren: () => import('src/app/modules/prime-components/prime-components.module').then(m => m.PrimeComponentsModule)
  },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
