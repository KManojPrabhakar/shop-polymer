import { Component, OnInit } from '@angular/core';
import {SelectItemGroup} from 'primeng/api';
import {SelectItem} from 'primeng/api';

interface City {
  name: string;
  code: string;
}
@Component({
  selector: 'app-select',
  templateUrl: './select.component.html',
  styleUrls: ['./select.component.css']
})
export class SelectComponent implements OnInit {

  cities1: SelectItem[];
  cities2: City[];

  selectedCity1: City;
  selectedCity2: City;
  selectedCar: string;

  groupedCars: SelectItemGroup[];
  constructor() {
    // SelectItem API with label-value pairs
    this.cities1 = [
        {label: 'Select City', value: null},
        {label: 'New York', value: {id: 1, name: 'New York', code: 'NY'}},
        {label: 'Rome', value: {id: 2, name: 'Rome', code: 'RM'}},
        {label: 'London', value: {id: 3, name: 'London', code: 'LDN'}},
        {label: 'Istanbul', value: {id: 4, name: 'Istanbul', code: 'IST'}},
        {label: 'Paris', value: {id: 5, name: 'Paris', code: 'PRS'}}
    ];
    // An array of cities
    this.cities2 = [
        {name: 'New York', code: 'NY'},
        {name: 'Rome', code: 'RM'},
        {name: 'London', code: 'LDN'},
        {name: 'Istanbul', code: 'IST'},
        {name: 'Paris', code: 'PRS'}
    ];
    // an array of grouped cars
    this.groupedCars = [
      {
          label: 'Germany',
          items: [
              {label: 'Audi', value: 'Audi'},
              {label: 'BMW', value: 'BMW'},
              {label: 'Mercedes', value: 'Mercedes'}
          ]
      },
      {
          label: 'USA',
          items: [
              {label: 'Cadillac', value: 'Cadillac'},
              {label: 'Ford', value: 'Ford'},
              {label: 'GMC', value: 'GMC'}
          ]
      },
      {
          label: 'Japan',
          items: [
              {label: 'Honda', value: 'Honda'},
              {label: 'Mazda', value: 'Mazda'},
              {label: 'Toyota', value: 'Toyota'}
          ]
      }
  ];
}

  ngOnInit() {
  }




}
