import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { RatingComponent } from './rating/rating.component';
import { SliderComponent } from './slider/slider.component';
import { TabMenuComponent } from './tab-menu/tab-menu.component';
import { AccordianComponent } from './accordian/accordian.component';
import { SelectComponent } from './select/select.component';
import { LightboxComponent } from './lightbox/lightbox.component';
import { ToastComponent } from './toast/toast.component';
import { CalenderComponent } from './calender/calender.component';
import { CarousalComponent } from './carousal/carousal.component';
import { TableComponent } from './table/table.component';
import { DataviewComponent } from './dataview/dataview.component';
import { ChartsComponent } from './charts/charts.component';



const routes: Routes = [
  {path: 'rating', component: RatingComponent},
  {path: 'slider', component: SliderComponent},
  {path: 'tabview', component: TabMenuComponent},
  {path: 'accordian', component: AccordianComponent},
  {path: 'select', component: SelectComponent},
  {path: 'lightbox', component: LightboxComponent},
  {path: 'toast', component: ToastComponent},
  {path: 'calender', component: CalenderComponent},
  {path: 'carousal', component: CarousalComponent},
  {path: 'table', component: TableComponent},
  {path: 'dataview', component: DataviewComponent},
  {path: 'chart', component: ChartsComponent},
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class PrimeComponentsRoutingModule { }
