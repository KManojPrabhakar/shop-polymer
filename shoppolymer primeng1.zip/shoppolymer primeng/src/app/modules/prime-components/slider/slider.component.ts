import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';

@Component({
  selector: 'app-slider',
  templateUrl: './slider.component.html',
  styleUrls: ['./slider.component.css']
})
export class SliderComponent implements OnInit {
  val = 10;
  rangeValues: number[] = [20, 80];
  exampleform: FormGroup;
  constructor() { }

  ngOnInit() {
    this.exampleform = new FormGroup({
      score: new FormControl('5', [Validators.required]),
    });
  }
}
