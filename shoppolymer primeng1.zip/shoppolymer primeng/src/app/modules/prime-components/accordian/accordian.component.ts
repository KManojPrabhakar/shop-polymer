import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-accordian',
  templateUrl: './accordian.component.html',
  styleUrls: ['./accordian.component.css']
})
export class AccordianComponent implements OnInit {
  index = 0;
  constructor() { }
  ngOnInit() {
  }
  openNext() {
    this.index = (this.index === 2) ? 0 : this.index + 1;
}

openPrev() {
    this.index = (this.index === 0) ? 2 : this.index - 1;
}
}
