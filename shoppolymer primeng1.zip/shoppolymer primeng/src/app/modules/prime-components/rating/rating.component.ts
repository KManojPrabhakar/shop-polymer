import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';

@Component({
  selector: 'app-rating',
  templateUrl: './rating.component.html',
  styleUrls: ['./rating.component.css']
})
export class RatingComponent implements OnInit {
  val = 3;
  exampleform: FormGroup;
scorevalue = 0;
  constructor() { }

  ngOnInit() {
    this.exampleform = new FormGroup({
      score: new FormControl('5', [Validators.required]),
    });
  }
  get data() { return this.exampleform.controls; }
  public onClickSubmit() {
    this.scorevalue = this.exampleform.value.score;
}
}
