import { Component, OnInit, OnChanges, SimpleChanges } from '@angular/core';
import { SharedService } from 'src/app/core/services/shared.service';
import { HelperService } from 'src/app/core/services/helper.service';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-list',
  templateUrl: './list.component.html',
  styleUrls: ['./list.component.css']
})
export class ListComponent implements OnInit, OnChanges {
  productsData: any
  currentProductId: any;
  currentCategoryName: string;
  constructor(private helperService: HelperService, private activatedRoute: ActivatedRoute) { }

  ngOnInit(): void {
    // this.currentProductId = this.activatedRoute.snapshot.paramMap.get('id');
    // this.currentProductId = Number(this.currentProductId);
    this.activatedRoute.params.subscribe(params => {
      console.log('params', params)
      this.currentProductId = params.id;
      this.currentProductId = Number(this.currentProductId);
      this.currentCategoryName = params.categoryName;

      this.getCurrentIdProductsData(this.currentCategoryName);
    })

  }
  ngOnChanges(changes: SimpleChanges) {
    console.log('changes id', changes.id);

    if (changes.id.currentValue !== changes.id.previousValue) {
      console.log('changes id', changes.id);
    }
  }

  getCurrentIdProductsData(categoryName) {
    this.productsData = this.helperService.getProductsData();
    console.log('productsData', this.productsData);
    if (this.productsData && this.productsData.length) {
      const findIndex = this.productsData.findIndex((item) => item.category === categoryName);
      console.log('productsData findIndex', findIndex);
      if (findIndex !== -1) {
        this.productsData = this.productsData[findIndex];
      }

    }

    console.log('productsData after findIndex', this.productsData);

  }


}
