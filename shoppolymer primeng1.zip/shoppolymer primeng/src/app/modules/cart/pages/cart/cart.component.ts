import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { HelperService } from 'src/app/core/services/helper.service';

@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.css']
})
export class CartComponent implements OnInit {

  cartsData: any;
  cartsTotalValue: any;
  constructor(private router: Router, private helperService: HelperService) { }

  ngOnInit(): void {
    this.cartsData = this.helperService.getCartsData();
    if(this.cartsData) {
      this.cartsData = JSON.parse(this.cartsData);
    }
    this.cartsTotalValue = this.getCartsTotalValue();
    console.log('this.cartsData total', this.getCartsTotalValue())
    console.log('this.cartsData', this.cartsData);
  }

  navigateToCheckOut() {
    console.log('navigateToCheckOut');
    const url = `checkout`;
    this.router.navigate([url]);
  }

  getCartsTotalValue() {
     let total;
     total = 0;
     this.cartsData.map((item) => {
       total+= item.price * item.quantity;
     })
     total = Number(total).toFixed(2);
     return total;
  }

  handleRemoveCartItem(cartData) {
    console.log('handleRemoveCartItem cart component', cartData);
    const findIndex = this.cartsData.findIndex((item) => item.name === cartData.name);
    if(findIndex !== -1) {
      this.cartsData.splice(findIndex, 1);
      this.helperService.setCartsData(this.cartsData);
      this.cartsTotalValue = this.getCartsTotalValue();
    }
    this.helperService.storeCartLength(this.cartsData.length);

   
    console.log(this.cartsData, 'cartsData');
  }

  handleCartItemQuantity(data) {
    console.log('handleCartItemQuantity', data);
    if(data.cartData) {
      const findIndex = this.cartsData.findIndex((item) => item.name === data.cartData.name);
      if(findIndex !== -1) {
        this.cartsData[findIndex].quantity = data.quantityData ? data.quantityData.name: this.cartsData[findIndex].quantity;
        this.helperService.setCartsData(this.cartsData);
        this.cartsTotalValue = this.getCartsTotalValue();
      }
    }
    this.helperService.storeCartLength(this.cartsData.length);

    
  }
  
}
