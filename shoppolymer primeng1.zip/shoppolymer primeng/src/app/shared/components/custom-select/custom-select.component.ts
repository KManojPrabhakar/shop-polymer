import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-custom-select',
  templateUrl: './custom-select.component.html',
  styleUrls: ['./custom-select.component.css']
})
export class CustomSelectComponent implements OnInit {
  @Input() labelName: string;
  @Input() optionsData: any;
  @Input() selectedOptionObj: any;
  @Output() emitDropDownValues = new EventEmitter();
  constructor() { }

  ngOnInit(): void {
  }
  handleOptionChange(value) {
    console.log('handleOptionChange', value);
    this.emitDropDownValues.emit(value);
  }

  dropdowntrackByFn(index: number | string, option: any) {
    if (option) {
      return option.id; // unique id corresponding to the item
    }
  }

}
