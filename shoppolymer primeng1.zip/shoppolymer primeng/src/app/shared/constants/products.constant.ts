export const ProductsData = [{
    "productId": 1,
    "id": 1,
    "category": "mens_outerwear",
    "title": "Men's Outerwear",
    "bannerImage": "assets/img/mens_outerwear.jpg",
    "products": [
      {
        "name":"YouTube+Organic+Cotton+T-Shirt+-+Grey",
        "title":"YouTube Organic Cotton T-Shirt - Grey",
        "category":"mens_outerwear",
        "price":14.75,
        "description":"Stay casual and cool in this 100% organic pre-shrunk cotton T-shirt. Available in charcoal grey with full-color YouTube logo screened on front.",
        "image": "assets/img/10-15068B.jpg",
        "largeImage":"data/images/10-13058A.jpg"
      },
      {
        "name":"Inbox+-+Subtle+Actions+T-Shirt",
        "title":"Inbox - Subtle Actions T-Shirt",
        "category":"mens_outerwear",
        "price":17.05,
        "description":"Sometimes even the subtlest of actions can make a big difference. This tee highlights all of the icons &amp;amp; features available in your Gmail inbox!&lt;div&gt;&lt;br&gt;&lt;/div&gt;&lt;div&gt;Features:&lt;/div&gt;&lt;div&gt;&lt;ul&gt;&lt;li&gt;60% cotton, 40% polyester blend.&lt;/li&gt;&lt;li&gt;Available in charcoal heather with the inbox icons screenprinted at front chest and inbox tag sewn onto left sleeve.&lt;/li&gt;&lt;/ul&gt;&lt;/div&gt;",
        "image": "assets/img/10-14157B.jpg",
        "largeImage":"data/images/10-13256A.jpg"
      }
    ]
    
  },
  {
    "productId": 2,
    "id": 2,
    "title": "Ladies Outerwear",
    "category": "ladies_outerwear",
    "bannerImage": "assets/img/ladies_outerwear.jpg",
    "products": [
        {
          "name":"Ladies+Modern+Stretch+Full+Zip",
          "title":"Ladies Modern Stretch Full Zip",
          "category":"ladies_outerwear",
          "price":41.60,
          "description":"With an updated fit and figure-flattering details, this full-zip combines ultra soft cotton with a dash of spandex to retain its shape all day long.&amp;nbsp;&lt;div&gt;&lt;br&gt;&lt;/div&gt;&lt;div&gt;Features:&lt;/div&gt;&lt;div&gt;&lt;ul&gt;&lt;li&gt;96% cotton, 4% spandex.&lt;/li&gt;&lt;li&gt;Gently contoured silhouette &amp;amp; longer length design for a style that moves with you.&lt;/li&gt;&lt;li&gt;Self-fabric hood.&lt;/li&gt;&lt;li&gt;Dyed-to-match zipper.&amp;nbsp;&lt;/li&gt;&lt;li&gt;Front slash pockets.&lt;/li&gt;&lt;li&gt;Open cuffs &amp;amp; hem.&lt;/li&gt;&lt;li&gt;Available in Mosaic Blue with the white Google logo embroidered at left chest.&amp;nbsp;&lt;/li&gt;&lt;/ul&gt;&lt;/div&gt;",
          "image": "assets/img/10-15068B.jpg",
          "largeImage":"data/images/10-24102A.jpg"
        },
        {
          "name":"Ladies+Colorblock+Wind+Jacket",
          "title":"Ladies Colorblock Wind Jacket",
          "category":"ladies_outerwear",
          "price":45.90,
          "description":"Brighten up your commute on gloomy days. This lightweight jacket features a subtle grid texture and a punch of bright pink at each side panel.&lt;div&gt;&lt;br&gt;&lt;/div&gt;&lt;div&gt;Features:&lt;/div&gt;&lt;div&gt;&lt;ul&gt;&lt;li&gt;100% polyester dobby shell with jersey lining.&lt;/li&gt;&lt;li&gt;Packable zip-in hood with contrast pink zipper.&lt;/li&gt;&lt;li&gt;Cadet collar and elastic cuffs.&lt;/li&gt;&lt;li&gt;Adjustable toggles at waist can be cinched for a flattering fit.&lt;/li&gt;&lt;li&gt;Available in grey/dark rose with the white Google logo embroidered at left chest.&lt;/li&gt;&lt;/ul&gt;&lt;/div&gt;",
          "image": "assets/img/10-15068B.jpg",
          "largeImage":"data/images/10-25058A.jpg"
        },
        {
          "name":"Ladies+Voyage+Fleece+Jacket",
          "title":"Ladies Voyage Fleece Jacket",
          "category":"ladies_outerwear",
          "price":48.00,
          "description":"&lt;div&gt;Perhaps the equivalent to that comfort blanket you had years ago is a cozy fleece. This full-zip is the perfect layering piece for those 'in-between' months when mother nature just can't make up her mind.&amp;nbsp;&lt;/div&gt;&lt;div&gt;&lt;br&gt;&lt;/div&gt;&lt;div&gt;Features:&lt;/div&gt;&lt;div&gt;&lt;ul&gt;&lt;li&gt;100% polyester anti-pill yarn fleece.&lt;/li&gt;&lt;li&gt;100% polyester taffeta lining in sleeves.&lt;/li&gt;&lt;li&gt;Tricot-lined lower pockets with reverse coil zippers.&lt;/li&gt;&lt;li&gt;Available in purple with the white Google logo embroidered at left chest.&lt;/li&gt;&lt;li&gt;&lt;b&gt;Please note! Sizing runs larger than normal. Consider ordering a size smaller than normal.&lt;/b&gt;&lt;/li&gt;&lt;/ul&gt;&lt;/div&gt;",
          "image": "assets/img/10-15068B.jpg",
          "largeImage":"data/images/10-24101A.jpg"
        },
        {
          "name":"Ladies+Pullover+L+S+Hood",
          "title":"Ladies Pullover L/S Hood",
          "category":"ladies_outerwear",
          "price":36.50,
          "description":"A longsleeve layering piece with a hood. What more can you ask for between season changes?&amp;nbsp;&lt;div&gt;&lt;br&gt;&lt;/div&gt;&lt;div&gt;Features:&lt;/div&gt;&lt;div&gt;&lt;ul&gt;&lt;li&gt;85% polyester, 15% cotton.&lt;/li&gt;&lt;li&gt;Ultra lightweight, tissue jersey fabric.&lt;/li&gt;&lt;li&gt;Scoop-neck with hood.&lt;/li&gt;&lt;li&gt;Available in jewel blue with the white Google logo screenprinted across center chest.&lt;/li&gt;&lt;/ul&gt;&lt;/div&gt;",
          "image": "assets/img/10-24102B.jpg",
          "largeImage":"data/images/10-24098A.jpg"
        },
        {
          "name":"Ladies+Sonoma+Hybrid+Knit+Jacket",
          "title":"Ladies Sonoma Hybrid Knit Jacket",
          "category":"ladies_outerwear",
          "price":84.85,
          "description":"A modern styled sport jacket that combines a classic silhouette with moisture-wicking fabrics. Technical features include a reversed coil zipper with reflective stripe, interior media exit port, and built-in media pocket.&amp;nbsp;&lt;div&gt;&lt;br&gt;&lt;/div&gt;&lt;div&gt;Additional Features:&lt;/div&gt;&lt;div&gt;&lt;ul&gt;&lt;li&gt;94% polyester, 6% spandex.&lt;/li&gt;&lt;li&gt;Available in black with the white Google logo heat transferred onto right hip along zipper.&lt;/li&gt;&lt;/ul&gt;&lt;/div&gt;",
          "image": "assets/img/10-24102B.jpg",
          "largeImage":"data/images/10-24097A.jpg"
        },
        {
          "name":"Ladies+Yerba+Knit+Quarter+Zip",
          "title":"Ladies Yerba Knit Quarter Zip",
          "category":"ladies_outerwear",
          "price":64.20,
          "description":"This on-trend quarter zip doubles as workout gear.&amp;nbsp;&lt;div&gt;&lt;br&gt;&lt;/div&gt;&lt;div&gt;Features:&lt;/div&gt;&lt;div&gt;&lt;ul&gt;&lt;li&gt;81% polyester, 19% spandex jersey knit.&lt;/li&gt;&lt;li&gt;Textured knit fabric features a moisture-wicking finish.&lt;/li&gt;&lt;li&gt;Exposed contrast reverse coil zipper with contrast inner collar.&lt;/li&gt;&lt;li&gt;Lightweight design with added stretch.&lt;/li&gt;&lt;li&gt;Available in heathered indigo with the white Google logo heat transferred vertically onto front right hip.&lt;/li&gt;&lt;/ul&gt;&lt;/div&gt;",
          "image": "assets/img/10-15068B.jpg",
          "largeImage":"data/images/10-24099A.jpg"
        }
      ]
      
  },
  {
    "productId": 3,
    "id": 3,
    "title": "Men's T-Shirts",
    "category": "mens_tshirts",
    "bannerImage": "assets/img/mens_tshirts.jpg",
    "products": [
      {
        "name":"YouTube+Organic+Cotton+T-Shirt+-+Grey",
        "title":"YouTube Organic Cotton T-Shirt - Grey",
        "category":"mens_tshirts",
        "price":14.75,
        "description":"Stay casual and cool in this 100% organic pre-shrunk cotton T-shirt. Available in charcoal grey with full-color YouTube logo screened on front.",
        "image": "assets/img/10-13239B.jpg",
        "largeImage":"data/images/10-13058A.jpg"
      },
      {
        "name":"Inbox+-+Subtle+Actions+T-Shirt",
        "title":"Inbox - Subtle Actions T-Shirt",
        "category":"mens_tshirts",
        "price":17.05,
        "description":"Sometimes even the subtlest of actions can make a big difference. This tee highlights all of the icons &amp;amp; features available in your Gmail inbox!&lt;div&gt;&lt;br&gt;&lt;/div&gt;&lt;div&gt;Features:&lt;/div&gt;&lt;div&gt;&lt;ul&gt;&lt;li&gt;60% cotton, 40% polyester blend.&lt;/li&gt;&lt;li&gt;Available in charcoal heather with the inbox icons screenprinted at front chest and inbox tag sewn onto left sleeve.&lt;/li&gt;&lt;/ul&gt;&lt;/div&gt;",
        "image": "assets/img/10-14157B.jpg",
        "largeImage":"data/images/10-13256A.jpg"
      },
      {
        "name":"Adult+Android+Superhero+T-Shirt",
        "title":"Adult Android Superhero T-Shirt",
        "category":"mens_tshirts",
        "price":14.95,
        "description":"Mr. Kent has nothing on Super Droid, especially since this robot has only one weakness-a sweet tooth (considering all of its confectionery-themed versions)! This adorable Bella+Canvas tee features a unisex fit that is sure to please both male and female Android fans.&lt;div&gt;&lt;br&gt;&lt;/div&gt;&lt;div&gt;Additional Features:&lt;/div&gt;&lt;div&gt;&lt;ul&gt;&lt;li&gt;100% combed, ringspun cotton.&lt;/li&gt;&lt;li&gt;Unisex fit.&lt;/li&gt;&lt;li&gt;Tag-free label for added comfort.&lt;/li&gt;&lt;li&gt;Available in royal blue with the Super Droid robot screen printed at center chest.&lt;/li&gt;&lt;li&gt;&lt;b&gt;Sizes run smaller than normal. Reference men's sizing chart for additional details.&lt;/b&gt;&lt;/li&gt;&lt;/ul&gt;&lt;/div&gt;",
        "image": "assets/img/10-14157B.jpg",
        "largeImage":"data/images/10-13239A.jpg"
      },
      {
        "name":"Men+s+Vintage+Heather+T-Shirt",
        "title":"Men's Vintage Heather T-Shirt",
        "category":"mens_tshirts",
        "price":15.8,
        "description":"&lt;div&gt;A casual-cool, vintage-inspired tee perfect for all. Just remember that the best part about any classic is that it only improves with age. The more you wash it, the softer it feels.&amp;nbsp;&lt;/div&gt;&lt;div&gt;&lt;br&gt;&lt;/div&gt;&lt;div&gt;Features:&lt;/div&gt;&lt;div&gt;&lt;ul&gt;&lt;li&gt;65% polyester, 35% cotton.&lt;/li&gt;&lt;li&gt;Available in heather navy, blue, purple or green with the white Google logo screened across center chest of each.&lt;/li&gt;&lt;/ul&gt;&lt;/div&gt;",
        "image": "assets/img/10-14157B.jpg",
        "largeImage":"data/images/10-13264A.jpg"
      },
      {
        "name":"Basic+Black+T-Shirt",
        "title":"Basic Black T-Shirt",
        "category":"mens_tshirts",
        "price":16.9,
        "description":"Word on the street is that 'black is the new black.' Embellish your basic fashion statement with the Google logo on an authentic American Apparel t-shirt.&amp;nbsp;&lt;div&gt;&lt;br&gt;&lt;/div&gt;&lt;div&gt;Features:&lt;/div&gt;&lt;div&gt;&lt;ul&gt;&lt;li&gt;100% organic combed cotton for ultimate softness.&amp;nbsp;&lt;/li&gt;&lt;li&gt;Flattering fit.&amp;nbsp;&lt;/li&gt;&lt;li&gt;Available in Black with the Google logo screen printed in White across center chest.&lt;/li&gt;&lt;li&gt;&lt;b&gt;Sizes run smaller than normal.&lt;/b&gt;&amp;nbsp;&lt;b&gt;Please reference men's size chart for fit.&lt;/b&gt;&lt;/li&gt;&lt;/ul&gt;&lt;/div&gt;",
        "image": "assets/img/10-14157B.jpg",
        "largeImage":"data/images/10-13265A.jpg"
      },
      {
        "name":"Local+Guides+T-Shirt",
        "title":"Local Guides T-Shirt",
        "category":"mens_tshirts",
        "price":15.7,
        "description":"Do you live to explore? Are you the first to tell your friends about the best venues, restaurants and hot spots in town? If you're already a local guide, sport your t-shirt with pride. This ultra soft style is comfortable enough to wear all day long - perfect for all of those adventures you'll tell us about later. To learn more about Local Guides, visit us here:&amp;nbsp;https://www.google.com/local/guides/.&lt;div&gt;&lt;br&gt;&lt;/div&gt;&lt;div&gt;Features:&lt;/div&gt;&lt;div&gt;&lt;ul&gt;&lt;li&gt;52% combed, ring-spun cotton / 48% polyester.&lt;/li&gt;&lt;li&gt;Retail fit.&lt;/li&gt;&lt;li&gt;Available in charcoal with the Local Guides logo screenprinted at front chest and Google logo screenprinted in white at left bicep.&lt;/li&gt;&lt;/ul&gt;&lt;/div&gt;",
        "image": "assets/img/10-13239B.jpg",
        "largeImage":"data/images/10-13280A.jpg"
      },
      {
        "name":"Go+Gopher+T-Shirt+in+Teal",
        "title":"Go Gopher T-Shirt in Teal",
        "category":"mens_tshirts",
        "price":10.95,
        "description":"Go anywhere in style when wearing this t-shirt featuring The Go Gopher. &amp;nbsp;Tee is made of 100% combed, ring-spun cotton jersey fabric. Available in teal with the Go Gopher screen printed on center.",
        "image": "assets/img/10-13239B.jpg",
        "largeImage":"data/images/10-13213A.jpg"
      },
      {
        "name":"Android+Ringspun+T-Shirt+-+Green",
        "title":"Android Ringspun T-Shirt - Green",
        "category":"mens_tshirts",
        "price":8.75,
        "description":"Display your undying love for Androids everywhere in this 100% certified organic ringspun cotton tee.&amp;nbsp;\n&lt;div&gt;&lt;br&gt;&lt;/div&gt;&lt;div&gt;Additional Features:&amp;nbsp;&lt;/div&gt;&lt;div&gt;&lt;ul&gt;&lt;li&gt;100% combed, ring-spun cotton.&amp;nbsp;&lt;/li&gt;&lt;li&gt;Preshrunk for fashion fit.&amp;nbsp;&lt;/li&gt;&lt;li&gt;Tearaway label.&amp;nbsp;\n&lt;/li&gt;&lt;li&gt;Available in heather green with the full color Android robot screen printed across center chest.&lt;/li&gt;&lt;/ul&gt;&lt;/div&gt;",
        "image": "assets/img/10-13239B.jpg",
        "largeImage":"data/images/10-13285A.jpg"
      }
      ]
      
  },
  {
    "productId": 4,
    "id": 4,
    "title": "Ladies T-Shirts",
    "category": "ladies_tshirts",
    "bannerImage": "assets/img/ladies_tshirts.jpg",
    "products": [
      {
        "name":"Ladies+Chrome+T-Shirt",
        "title":"Ladies Chrome T-Shirt",
        "category":"ladies_tshirts",
        "price":13.30,
        "description":"The best of three fabrics combined into one seductively-soft tee.&amp;nbsp;&lt;div&gt;&lt;br&gt;&lt;/div&gt;&lt;div&gt;Features:&lt;/div&gt;&lt;div&gt;&lt;ul&gt;&lt;li&gt;50% polyester, 25% combed and ring-spun cotton, 25% rayon.&lt;/li&gt;&lt;li&gt;Side-seamed.&lt;/li&gt;&lt;li&gt;Semi-relaxed fit.&amp;nbsp;&lt;/li&gt;&lt;li&gt;Available in heather blue with the white Google Chrome logo screenprinted at center chest.&amp;nbsp;&lt;/li&gt;&lt;/ul&gt;&lt;/div&gt;",
        "image": "assets/img/10-23172B.jpg",
        "largeImage":"data/images/10-23180A.jpg"
      },
      {
        "name":"Ladies+Google+New+York+T-Shirt",
        "title":"Ladies Google New York T-Shirt",
        "category":"ladies_tshirts",
        "price":18.35,
        "description":"Are you feeling lucky? Inspired by city lights in The Big Apple, this tee features the 'I'm Feeling Lucky New York' phrase at back.&lt;div&gt;&lt;br&gt;&lt;/div&gt;&lt;div&gt;Features:&lt;/div&gt;&lt;div&gt;&lt;ul&gt;&lt;li&gt;100% cotton.&lt;/li&gt;&lt;li&gt;American Apparel shirt designed with a ladies fit in mind.&lt;/li&gt;&lt;li&gt;Available in Black with the Google logo and 'I'm Feeling Lucky' New York printed on back yoke in White.&lt;/li&gt;&lt;li&gt;&lt;b&gt;Sizing runs smaller than normal. Please reference size chart before ordering.&lt;/b&gt;&lt;/li&gt;&lt;/ul&gt;&lt;/div&gt;",
        "image": "assets/img/10-23172B.jpg",
        "largeImage":"data/images/10-23226A.jpg"
      },
      {
        "name":"Ladies+Gmail+T-Shirt",
        "title":"Ladies Gmail T-Shirt",
        "category":"ladies_tshirts",
        "price":16.40,
        "description":"Show your inbox some love. The new Gmail tee has arrived, complete with a subtle Mvelope design that showcases all of the Gmail icons you use on the daily.&lt;div&gt;&lt;br&gt;&lt;/div&gt;&lt;div&gt;Features:&lt;/div&gt;&lt;div&gt;&lt;ul&gt;&lt;li&gt;50% polyester, 25% cotton.&lt;/li&gt;&lt;li&gt;Bella+Canvas.&lt;/li&gt;&lt;li&gt;Available in vintage red with the new Gmail print screenprinted across center chest.&lt;/li&gt;&lt;/ul&gt;&lt;/div&gt;",
        "image": "assets/img/10-23172B.jpg",
        "largeImage":"data/images/10-23179A.jpg"
      },
      {
        "name":"Ladies+G+Logo+White+T-Shirt",
        "title":"Ladies G Logo White T-Shirt",
        "category":"ladies_tshirts",
        "price":13.30,
        "description":"There's a new G in town and it's here to stay. Get your hands on this comfy white tee with the new Google icon.&amp;nbsp;\n\n&lt;div&gt;&lt;br&gt;&lt;/div&gt;&lt;div&gt;Features:&amp;nbsp;&lt;/div&gt;&lt;div&gt;&lt;ul&gt;&lt;li&gt;100% combed and ring-spun cotton.&lt;/li&gt;&lt;li&gt;Side seamed, relaxed fit.&lt;/li&gt;&lt;li&gt;Bella+Canvas.&lt;/li&gt;&lt;li&gt;Available in white with the Google 'G' icon screenprinted at front.&lt;/li&gt;&lt;/ul&gt;&lt;/div&gt;",
        "image": "assets/img/10-14157B.jpg",
        "largeImage":"data/images/10-23178A.jpg"
      },
      {
        "name":"Ladies+Android+Pride+T-Shirt",
        "title":"Ladies Android Pride T-Shirt",
        "category":"ladies_tshirts",
        "price":19.10,
        "description":"Stand out proud in this Ladies' Android Pride T-shirt.&amp;nbsp;&lt;div&gt;&lt;br&gt;&lt;/div&gt;&lt;div&gt;Features:&lt;/div&gt;&lt;div&gt;&lt;ul&gt;&lt;li&gt;100% cotton.&lt;/li&gt;&lt;li&gt;Available in black and features two Androids holding hands and waving a rainbow flag printed across the front. Google logo screen printed in white on the sleeve.&amp;nbsp;&lt;/li&gt;&lt;li&gt;&lt;b&gt;Sizing runs smaller than normal. Please reference size chart before ordering.&lt;/b&gt;&lt;/li&gt;&lt;/ul&gt;&lt;/div&gt;",
        "image": "assets/img/10-23172B.jpg",
        "largeImage":"data/images/10-23177A.jpg"
      },
      {
        "name":"Ladies+Ringspun+Crew+Neck",
        "title":"Ladies Ringspun Crew Neck",
        "category":"ladies_tshirts",
        "price":19.70,
        "description":"Cheery colors make the world a happier place. This bright pink tee is ultra soft and features a comfortable, ladies fit.&lt;div&gt;&lt;br&gt;&lt;/div&gt;&lt;div&gt;Features:&lt;/div&gt;&lt;div&gt;&lt;ul&gt;&lt;li&gt;100% cotton.&lt;/li&gt;&lt;li&gt;Tagless label for added comfort.&lt;/li&gt;&lt;li&gt;&lt;b&gt;Relaxed fit.&lt;/b&gt;&lt;/li&gt;&lt;li&gt;Available in hot pink with the white Google logo screenprinted at center chest.&lt;/li&gt;&lt;/ul&gt;&lt;/div&gt;",
        "image": "assets/img/10-23172B.jpg",
        "largeImage":"data/images/10-23172A.jpg"
      },
      {
        "name":"Ladies+Tri-Blend+V-Neck+T-Shirt",
        "title":"Ladies Tri-Blend V-Neck T-Shirt",
        "category":"ladies_tshirts",
        "price":35.10,
        "description":"A tagless label, ultra soft triblend fabric and v-neck cut are three ingredients for a favorite tee.&amp;nbsp;&lt;div&gt;&lt;br&gt;&lt;/div&gt;&lt;div&gt;Features:&lt;/div&gt;&lt;div&gt;&lt;ul&gt;&lt;li&gt;25% cotton, 50% polyester, 25% rayon.&lt;/li&gt;&lt;li&gt;Made in California.&lt;/li&gt;&lt;li&gt;Available in green with the white Google logo screenprinted at center chest.&lt;/li&gt;&lt;/ul&gt;&lt;/div&gt;",
        "image": "assets/img/10-14157B.jpg",
        "largeImage":"data/images/10-23227A.jpg"
      },
      {
        "name":"Bella+Ladies+Favorite+Tee",
        "title":"Bella Ladies Favorite Tee",
        "category":"ladies_tshirts",
        "price":10.50,
        "description":"This ladies tee features a longer body length perfect for layering up.&amp;nbsp;&lt;div&gt;&lt;br&gt;&lt;/div&gt;&lt;div&gt;Features:&lt;/div&gt;&lt;div&gt;&lt;ul&gt;&lt;li&gt;100% combed, ringspun cotton.&lt;/li&gt;&lt;li&gt;Extra soft, lightweight fabric.&lt;/li&gt;&lt;li&gt;&lt;b&gt;Slim fit. Runs small.&amp;nbsp;&lt;/b&gt;&lt;/li&gt;&lt;li&gt;Available in aqua with the white Google logo screenprinted at center chest.&lt;/li&gt;&lt;/ul&gt;&lt;/div&gt;",
        "image": "assets/img/10-14157B.jpg",
        "largeImage":"data/images/10-23228A.jpg"
      },
      {
        "name":"Ladies+Bamboo+T-Shirt",
        "title":"Ladies Bamboo T-Shirt",
        "category":"ladies_tshirts",
        "price":20.65,
        "description":"A bamboo tee that's softer than your favorite cotton t-shirt. Your skin will thank you during those long nights of programming.&amp;nbsp;&lt;div&gt;&lt;br&gt;&lt;/div&gt;&lt;div&gt;Features:&lt;/div&gt;&lt;div&gt;&lt;ul&gt;&lt;li&gt;70% viscose from organic bamboo, 30% organic cotton.&lt;/li&gt;&lt;li&gt;Available in vintage pink with the white Google logo screen printed at center chest.&lt;/li&gt;&lt;/ul&gt;&lt;/div&gt;",
        "image": "assets/img/10-14157B.jpg",
        "largeImage":"data/images/10-23176A.jpg"
      },
      {
        "name":"Ladies+L+S+Colorblock+Raglan",
        "title":"Ladies L/S Colorblock Raglan",
        "category":"ladies_tshirts",
        "price":36.95,
        "description":"Add a dose of mango to your t-shirt lineup. This scoop neck raglan features a bright pop of color and a scoop neck with v-notch.&lt;div&gt;&lt;br&gt;&lt;/div&gt;&lt;div&gt;Features:&lt;/div&gt;&lt;div&gt;&lt;ul&gt;&lt;li&gt;60% cotton, 40% polyester.&lt;/li&gt;&lt;li&gt;Scoop hem.&lt;/li&gt;&lt;li&gt;Self-fabric cuff bands.&lt;/li&gt;&lt;li&gt;Available in heather/mango with the white Google logo screenprinted at center chest.&lt;/li&gt;&lt;/ul&gt;&lt;/div&gt;",
        "image": "assets/img/10-14157B.jpg",
        "largeImage":"data/images/10-23173A.jpg"
      },
      {
        "name":"Bella+Scoop-Neck+Ladies+T-Shirt",
        "title":"Bella Scoop-Neck Ladies T-Shirt",
        "category":"ladies_tshirts",
        "price":13.10,
        "description":"A classic that's here to stay is this ladies white baby ribbed tee. Features a feminine scoop cut at the neck and 1x1 baby rib texture. Available in white with the full color Google logo screen printed at center chest.",
        "image": "assets/img/10-14157B.jpg",
        "largeImage":"data/images/10-23171A.jpg"
      },
      {
        "name":"Ladies+Not+For+Sale+T-Shirt",
        "title":"Ladies Not For Sale T-Shirt",
        "category":"ladies_tshirts",
        "price":24.00,
        "description":"This Not for Sale t-shirt features just the right amount of 'V' around the neck with the Google logo placed perfectly underneath. Not for Sale focuses efforts on growing social enterprises to benefit those enslaved and vulnerable communities around the world.&amp;nbsp;&lt;div&gt;&lt;br&gt;&lt;/div&gt;&lt;div&gt;Features:&lt;/div&gt;&lt;div&gt;&lt;ul&gt;&lt;li&gt;Available in black with the Google logo imprinted in white across upper chest.&lt;/li&gt;&lt;li&gt;&lt;b&gt;Sizing runs smaller than normal. Please consider ordering up one or two sizes.&lt;/b&gt;&lt;/li&gt;&lt;/ul&gt;&lt;/div&gt;",
        "image": "assets/img/10-14157B.jpg",
        "largeImage":"data/images/10-23225A.jpg"
      }
      ]
      
  }
]
